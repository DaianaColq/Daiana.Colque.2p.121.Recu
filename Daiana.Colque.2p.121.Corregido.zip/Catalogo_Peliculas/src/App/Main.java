package App;

import Modelo.*;

import java.io.IOException;

public class Main {

    public static void main(String[] args) {

        try {
            // Crear catálogo de películas
            Catalogo<Pelicula> catalogoPeliculas = new Catalogo<>();

            catalogoPeliculas.agregar(new Pelicula(1, "El Padrino", "Francis Ford Coppola", Genero.DRAMA));
            catalogoPeliculas.agregar(new Pelicula(2, "La La Land", "Damien Chazelle", Genero.COMEDIA));
            catalogoPeliculas.agregar(new Pelicula(3, "Guerra Mundial Z", "Marc Forster", Genero.TERROR));
            catalogoPeliculas.agregar(new Pelicula(4, "Toy Story", "John Lasseter", Genero.ANIMACION));
            catalogoPeliculas.agregar(new Pelicula(5, "The Social Dilemma", "Jeff Orlowski", Genero.DOCUMENTAL));

            // Mostrar películas
            System.out.println("Catálogo de películas:");
            catalogoPeliculas.paraCadaElemento(p -> System.out.println(p));

            // Filtrar por género COMEDIA
            System.out.println("\nPelículas de género COMEDIA:");
            catalogoPeliculas.filtrar(p -> p.getGenero() == Genero.COMEDIA)
                             .forEach(p -> System.out.println(p));

            // Filtrar por título con la palabra "Guerra"
            System.out.println("\nPelículas cuyo título contiene 'Guerra':");
            catalogoPeliculas.filtrar(p -> p.getTitulo().contains("Guerra"))
                             .forEach(p -> System.out.println(p));

            // Orden natural por ID
            System.out.println("\nPelículas ordenadas de manera natural (por id):");
            catalogoPeliculas.ordenar();
            catalogoPeliculas.paraCadaElemento(p -> System.out.println(p));

            // Ordenar por título
            System.out.println("\nPelículas ordenadas por título:");
            catalogoPeliculas.ordenar((p1, p2) -> p1.getTitulo().compareTo(p2.getTitulo()));
            catalogoPeliculas.paraCadaElemento(p -> System.out.println(p));

            // Guardar en archivo binario
            catalogoPeliculas.guardarEnArchivo("data/peliculas.dat");

            // Guardar en CSV
            catalogoPeliculas.guardarEnCSV("data/peliculas.csv");
            
            // Cargar desde archivo binario
            Catalogo<Pelicula> catalogoCargado = new Catalogo<>();
            catalogoCargado.cargarDesdeArchivo("data/peliculas.dat");
            System.out.println("\nPelículas cargadas desde archivo binario:");
            catalogoCargado.paraCadaElemento(p -> System.out.println(p));

            // Cargar desde archivo CSV
            catalogoCargado.cargarDesdeCSV("data/peliculas.csv", Pelicula::fromCSV);
            System.out.println("\nPelículas cargadas desde archivo CSV:");
            catalogoCargado.paraCadaElemento(p -> System.out.println(p));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
