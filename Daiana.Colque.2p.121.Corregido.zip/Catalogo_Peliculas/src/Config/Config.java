package Config;

public class Config {
    public static final String ARCHIVO_BINARIO = "src/data/peliculas.dat";
    public static final String ARCHIVO_CSV = "src/data/peliculas.csv";
}
