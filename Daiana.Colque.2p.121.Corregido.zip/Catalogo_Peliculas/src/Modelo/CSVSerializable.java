package Modelo;

public interface CSVSerializable {
    String toCSV();
}
