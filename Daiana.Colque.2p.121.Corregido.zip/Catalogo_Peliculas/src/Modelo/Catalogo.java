package Modelo;

import java.io.*;
import java.util.*;
import java.util.function.*;

public class Catalogo<T extends CSVSerializable & Comparable<T>> implements Serializable {
    private ArrayList<T> elementos = new ArrayList<>();

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public T obtener(int indice) {
        return elementos.get(indice);
    }

    public void eliminar(int indice) {
        elementos.remove(indice);
    }

    public void paraCadaElemento(Consumer<T> consumidor) {
        for (T e : elementos) {
            consumidor.accept(e);
        }
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T e : elementos) {
            if (criterio.test(e)) {
                resultado.add(e);
            }
        }
        return resultado;
    }

    public void ordenar() {
        Collections.sort(elementos);
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ruta))) {
            out.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (ArrayList<T>) (List<T>) in.readObject();
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                writer.println(elemento.toCSV());
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        elementos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                elementos.add(fromCSV.apply(linea));
            }
        }
    }
}