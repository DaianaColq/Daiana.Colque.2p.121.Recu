package modelo;

import java.nio.file.Path;
import java.nio.file.Paths;

public class AppConfig {
    public static final Path PATH_SER = Paths.get("data", "torneos.ser");
    public static final Path PATH_CSV = Paths.get("data", "torneos.csv");
}
