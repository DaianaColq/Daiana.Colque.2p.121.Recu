package modelo.interfaces;

public interface CSVSerializable {
    String toCSV();
    String toHeaderCSV();
}
