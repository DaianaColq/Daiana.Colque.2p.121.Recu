package modelo;

public enum CategoriaVideojuego {
    ONLINE,
    PRESENCIAL
}
