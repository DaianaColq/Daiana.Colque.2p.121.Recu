package modelo.interfaces;

import java.util.List;
import java.util.function.Predicate;
import java.util.Comparator;

public interface Gestionable<T> {
    void agregar(T elemento);
    void eliminar(int indice);
    T obtener(int indice);
    void limpiar();

    void ordenar(); // orden natural
    void ordenar(Comparator<T> criterio); // orden personalizado

    List<T> filtrar(Predicate<T> criterio);

    void guardarEnBinario(String ruta) throws Exception;
    void cargarDesdeBinario(String ruta) throws Exception;

    void guardarEnCSV(String ruta) throws Exception;
    void cargarDesdeCSV(String ruta, java.util.function.Function<String, T> fromCSV) throws Exception;

    void mostrarTodos();
}
