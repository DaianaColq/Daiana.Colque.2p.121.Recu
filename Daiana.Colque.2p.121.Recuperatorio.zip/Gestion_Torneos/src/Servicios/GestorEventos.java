package servicios;

import modelo.interfaces.Gestionable;
import modelo.interfaces.CSVSerializable;

import java.io.*;
import java.util.*;
import java.util.function.Predicate;
import java.util.function.Function;

public class GestorEventos<T extends CSVSerializable & Comparable<T>> implements Gestionable<T> {

    private List<T> lista;

    public GestorEventos() {
        lista = new ArrayList<>();
    }

    @Override
    public void agregar(T elemento) {
        lista.add(elemento);
    }

    @Override
    public void eliminar(int indice) {
        if (indice >= 0 && indice < lista.size()) {
            lista.remove(indice);
        } else {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
    }

    @Override
    public T obtener(int indice) {
        if (indice >= 0 && indice < lista.size()) {
            return lista.get(indice);
        } else {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
    }

    @Override
    public void limpiar() {
        lista.clear();
    }

    @Override
    public void ordenar() {
        Collections.sort(lista);
    }

    @Override
    public void ordenar(Comparator<T> criterio) {
        lista.sort(criterio);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T elem : lista) {
            if (criterio.test(elem)) {
                resultado.add(elem);
            }
        }
        return resultado;
    }

    @Override
    public void guardarEnBinario(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public void cargarDesdeBinario(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            lista = (List<T>) ois.readObject();
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws IOException {
        if (lista.isEmpty()) return;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            // Escribo el header a partir del primer elemento
            bw.write(lista.get(0).toHeaderCSV());
            bw.newLine();

            for (T elem : lista) {
                bw.write(elem.toCSV());
                bw.newLine();
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        lista.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea = br.readLine(); // header, lo ignoro
            while ((linea = br.readLine()) != null) {
                lista.add(fromCSV.apply(linea));
            }
        }
    }

    @Override
    public void mostrarTodos() {
        for (T elem : lista) {
            System.out.println(elem);
        }
    }
}
