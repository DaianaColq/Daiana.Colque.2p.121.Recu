package tester;

import modelo.*;
import servicios.GestorEventos;

import java.time.LocalDate;
import java.util.List;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        try {
            // Crear instancia del gestor
            GestorEventos<TorneoVideojuego> gestor = new GestorEventos<>();

            // Agregar torneos de videojuegos
            gestor.agregar(new TorneoVideojuego(1, "Campeonato de League of Legends", LocalDate.of(2024, 12, 10), "Team Alpha", CategoriaVideojuego.ONLINE));
            gestor.agregar(new TorneoVideojuego(2, "Torneo de FIFA 24", LocalDate.of(2024, 11, 20), "FIFA Legends", CategoriaVideojuego.PRESENCIAL));
            gestor.agregar(new TorneoVideojuego(3, "Competencia de Fortnite", LocalDate.of(2024, 12, 5), "Battle Stars", CategoriaVideojuego.ONLINE));
            gestor.agregar(new TorneoVideojuego(4, "Campeonato de Valorant", LocalDate.of(2025, 1, 15), "Valorant Pros", CategoriaVideojuego.PRESENCIAL));

            // Mostrar torneos agregados
            System.out.println("Torneos iniciales:");
            gestor.mostrarTodos();

            // Filtrar torneos por categoría
            System.out.println("\nFiltrar por categoría: ONLINE");
            List<TorneoVideojuego> torneosOnline = gestor.filtrar(t -> t.getCategoria() == CategoriaVideojuego.ONLINE);
            for (TorneoVideojuego t : torneosOnline) {
                System.out.println(t);
            }

            // Filtrar torneos por rango de fechas
            System.out.println("\nFiltrar por rango de fechas (2024-12-01 a 2024-12-31):");
            List<TorneoVideojuego> rangoFechas = gestor.filtrar(t -> !t.getFecha().isBefore(LocalDate.of(2024,12,1)) && !t.getFecha().isAfter(LocalDate.of(2024,12,31)));
            for (TorneoVideojuego t : rangoFechas) {
                System.out.println(t);
            }

            // Ordenar torneos por nombre
            System.out.println("\nTorneos ordenados por nombre:");
            gestor.ordenar(Comparator.comparing(TorneoVideojuego::getNombre));
            gestor.mostrarTodos();

            // Ordenar torneos por fecha
            System.out.println("\nTorneos ordenados por fecha:");
            gestor.ordenar();
            gestor.mostrarTodos();

            // Guardar y cargar en archivo binario
            gestor.guardarEnBinario(AppConfig.PATH_SER.toString());
            GestorEventos<TorneoVideojuego> gestorBinario = new GestorEventos<>();
            gestorBinario.cargarDesdeBinario(AppConfig.PATH_SER.toString());
            System.out.println("\nTorneos cargados desde archivo binario:");
            gestorBinario.mostrarTodos();
            
            // Guardar y cargar en archivo CSV
            gestor.guardarEnCSV(AppConfig.PATH_CSV.toString());
            GestorEventos<TorneoVideojuego> gestorCSV = new GestorEventos<>();
            gestorCSV.cargarDesdeCSV(AppConfig.PATH_CSV.toString(), TorneoVideojuego::fromCSV);
            System.out.println("\nTorneos cargados desde archivo CSV:");
            gestorCSV.mostrarTodos();

            // Eliminar torneo
            System.out.println("\nEliminar torneo con índice 1:");
            gestor.eliminar(1);
            gestor.mostrarTodos();

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
