package modelo;

import modelo.interfaces.CSVSerializable;
import java.time.LocalDate;

public class TorneoVideojuego extends Torneo implements CSVSerializable, Comparable<TorneoVideojuego> {
    private String equipoPrincipal;
    private CategoriaVideojuego categoria;

    public TorneoVideojuego(int id, String nombre, LocalDate fecha, String equipoPrincipal, CategoriaVideojuego categoria) {
        super(id, nombre, fecha);
        this.equipoPrincipal = equipoPrincipal;
        this.categoria = categoria;
    }

    public String getEquipoPrincipal() {
        return equipoPrincipal;
    }

    public CategoriaVideojuego getCategoria() {
        return categoria;
    }

    @Override
    public int compareTo(TorneoVideojuego otro) {
        return this.fecha.compareTo(otro.fecha);
    }

    @Override
    public String toString() {
        return super.toString() + ", equipoPrincipal=" + equipoPrincipal + ", categoria=" + categoria;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + fecha + "," + equipoPrincipal + "," + categoria;
    }

    @Override
    public String toHeaderCSV() {
        return "id,nombre,fecha,equipoPrincipal,categoria";
    }

    public static TorneoVideojuego fromCSV(String linea) {
        String[] campos = linea.split(",");
        int id = Integer.parseInt(campos[0]);
        String nombre = campos[1];
        LocalDate fecha = LocalDate.parse(campos[2]);
        String equipoPrincipal = campos[3];
        CategoriaVideojuego categoria = CategoriaVideojuego.valueOf(campos[4]);
        return new TorneoVideojuego(id, nombre, fecha, equipoPrincipal, categoria);
    }
}
